<?php 
use ReCaptcha\ReCaptcha;

require '../vendor/autoload.php';

$recatcha=new ReCaptcha('6LfjkkIUAAAAAE2A8yNTqo1t8sGvLIfZVGNs-utG');
 ?>